/* =========================================
   SCRIPT PÁGINA NOSSAS IDEIAS
   ========================================= */

document.addEventListener('DOMContentLoaded', () => {
    
    // Configuração do Carrossel de Vencedores
    const btnPrev = document.getElementById('btn-prev');
    const btnNext = document.getElementById('btn-next');
    const track = document.getElementById('winners-container');

    // Distância do Scroll (Tamanho do Card 350px + Gap 24px = 374px)
    const scrollAmount = 380; 

    if (btnPrev && btnNext && track) {
        
        btnPrev.addEventListener('click', () => {
            track.scrollBy({
                left: -scrollAmount,
                behavior: 'smooth'
            });
        });

        btnNext.addEventListener('click', () => {
            track.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        });

        console.log("Carrossel de Vencedores ativado.");
    } else {
        console.log("Elementos do carrossel não encontrados.");
    }
});